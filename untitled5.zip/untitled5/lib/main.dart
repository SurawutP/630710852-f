import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});

  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Call API',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Call API'),
        ),
        body: APIWidget(),
      ),
    );
  }
}

class APIWidget extends StatefulWidget {
  const APIWidget({super.key});

  State<APIWidget> createState() => _APIWidget();
}

class _APIWidget extends State<APIWidget> {
  var data = null;
  var dataVote = null;
  var votedCountry = null;
  var domainName = "https://cpsu-test-api.herokuapp.com/api/polls";
  var viewVote = false;
  var s = null;
  void callAPI() async {
    var res = await http.get(Uri.parse("$domainName"));
    setState(() {
      var resJson = jsonDecode(res.body);
      data = resJson["data"];
    });
  }

  void callVoteDataAPI() async {
    var res = await http.get(Uri.parse("$domainName/vote"));
    print(res.body);
    setState(() {
      var resJson = jsonDecode(res.body);
      dataVote = resJson["data"];
    });
  }

  void initState() {
    super.initState();
    callAPI();
    callVoteDataAPI();
  }

  Widget build(BuildContext context) {
    if (data == null) {
      return Center(
        child: CircularProgressIndicator(),
      );
    }

    List<Widget> widgetList = data.map<Widget>((obj) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 50),
            Container(

              height: 100,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text("${obj["id"]}. "),
                      Text(
                        obj["question"],
                        style: const TextStyle(
                          fontSize: 15,

                        ),
                      ),
                    ],
                  ),


                ],
              ),
            ),

            Expanded(

              child: Container(
                height: 100,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () async {

                        var res = await http
                            .post(Uri.parse("$domainName/vote"), body: {
                          "choices": "${obj["choices"]}",
                        });
                        print(res.body);

                        setState(() {
                          votedCountry = obj["id"];
                          votedCountry = obj["name"];
                        });
                      },
                      child: Text( "void", style: TextStyle(fontSize: 20)),
                    )
                  ],
                ),
              ),
            )

          ]),
        ),
      );
    }).toList();

    Widget popupWidget = votedCountry == null ? Container() : createPopup();
    Widget viewVoteButton = Container(
      width: double.infinity,
      height: double.infinity,
      alignment: Alignment.bottomCenter,
      child: ElevatedButton(
        onPressed: () {
          setState(() {
            viewVote = true;
            callVoteDataAPI();
          });
        },
        child: const Text("View"),
      ),
    );

    Widget votePage = viewVote ? createViewVotePage() : Container();

    return Stack(
      children: [
        Container(
          child: ListView(children: widgetList),
        ),
        viewVoteButton,
        votePage,
        popupWidget
      ],
    );
  }

 

  Widget createPopup() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Colors.black.withOpacity(0.5),
      child: Center(
          child: Container(
            width: 300,
            height: 300,
            color: Colors.white,
            child: Padding(
              padding: EdgeInsets.all(30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 1,
                    child: Text("SUCCESS"),
                  ),
                  Expanded(
                    flex: 1,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("You voted $votedCountry"),
                        Text("Data saved successfully")
                      ],
                    ),
                  ),
                  Expanded(
                      flex: 1,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  votedCountry = null;
                                });
                              },
                              child: Text("OK"))
                        ],
                      )),
                ],
              ),
            ),
          )),
    );
  }

  createViewVotePage() {}
}
